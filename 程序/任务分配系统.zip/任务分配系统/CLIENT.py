import airsim
import random
import tkinter as tk
import time
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import threading

# 设置matplotlib支持中文显示
def setup_matplotlib_font():
    plt.rcParams["font.family"] = ["SimHei", "sans-serif"]
    plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

# 在模块加载时就设置字体
setup_matplotlib_font()




class Swarm:
    def __init__(self,count=3):
        self.count = count
        self._client = airsim.MultirotorClient()
        
        # 初始化无人机列表并为每架无人机启用控制
        self.drone_list = []
        for i in range(self.count):
            drone_name = "Drone"+str(i)
            self.drone_list.append(drone_name)
            # 为每架无人机单独启用API控制和解锁电机
            self._client.enableApiControl(True, vehicle_name=drone_name)
            self._client.armDisarm(True, vehicle_name=drone_name)

        
    
    def takeoff(self):
        tasks=[]
        for i in range(self.count):
            tasks.append(self._client.takeoffAsync(vehicle_name=self.drone_list[i]))
        for task in tasks:
            task.join()
            
    def land(self):    
        #关闭电机，释放API控制
        for i in range(self.count):
            self._client.armDisarm(False, vehicle_name=self.drone_list[i])
            self._client.enableApiControl(False, vehicle_name=self.drone_list[i])
        print("已释放API控制和解锁电机")
            
    
    def moveByVelocity(self,velocity_x,velocity_y,velocity_z,duration):
        tasks=[]
        for i in range(self.count):
            tasks.append(self._client.moveByVelocityAsync(vehicle_name=self.drone_list[i],
                                                          vx=velocity_x,
                                                          vy=velocity_y,
                                                          vz=velocity_z,
                                                          duration=duration))
        for task in tasks:
            task.join()

    def getPosition(self):
        """
        获取无人机位置
        Returns:
            list: 无人机位置列表，每个元素为airsim.Vector3r类型,ned坐标
        """
        positions=[]
        for drone in self.drone_list:
            position=self._client.getMultirotorState(vehicle_name=drone).kinematics_estimated.position
            positions.append(position)
        return positions


class State:
    def __init__(self):
        self.position=[0.0,0.0,0.0]
        self.orientation=[0.0,0.0,0.0,0.0]
        self.linear_velocity=[0.0,0.0,0.0]
        self.angular_velocity=[0.0,0.0,0.0]
        
        self.battery=100.0
        self.maxload=100.0
        self.currentload=0.0

    def __str__(self):
       return(f'''[position:{self.position}\n
orientation:{self.orientation}\n
linear_velocity:{self.linear_velocity}\n
angular_velocity:{self.angular_velocity}\n
battery:{self.battery}]\n''') 
                  

class Vehicle:
    
    def __init__(self,drone_name="Drone0"):
        self.drone_name=drone_name
        self._client = airsim.MultirotorClient()

        #无人机属性
        position=self._client.getMultirotorState(vehicle_name=self.drone_name).kinematics_estimated.position
        orientation=self._client.getMultirotorState(vehicle_name=self.drone_name).kinematics_estimated.orientation
        linear_velocity=self._client.getMultirotorState(vehicle_name=self.drone_name).kinematics_estimated.linear_velocity
        angular_velocity=self._client.getMultirotorState(vehicle_name=self.drone_name).kinematics_estimated.angular_velocity
        
        # 无人机状态
        self.state=State()
        self.state.position=[position.x_val,position.y_val,position.z_val]
        self.state.orientation=[orientation.w_val,orientation.x_val,orientation.y_val,orientation.z_val]
        self.state.linear_velocity=[linear_velocity.x_val,linear_velocity.y_val,linear_velocity.z_val]
        self.state.angular_velocity=[angular_velocity.x_val,angular_velocity.y_val,angular_velocity.z_val]
    
    #更新状态
    def updateState(self):
        s=self._client.getMultirotorState(vehicle_name=self.drone_name).kinematics_estimated
        
        position=s.position
        orientation=s.orientation
        linear_velocity=s.linear_velocity
        angular_velocity=s.angular_velocity
        
        self.state.position=[position.x_val,position.y_val,position.z_val]
        self.state.orientation=[orientation.w_val,orientation.x_val,orientation.y_val,orientation.z_val]
        self.state.linear_velocity=[linear_velocity.x_val,linear_velocity.y_val,linear_velocity.z_val]
        self.state.angular_velocity=[angular_velocity.x_val,angular_velocity.y_val,angular_velocity.z_val]
    
    
#..................................................................
#..................................................................


class Task:
    def __init__(self):
        self.type = ""
        self.duration = 0
        self.workload = 0  # 0-100
        self.priority = 0
        
    # 定义比较方法，实现先按priority排序，再按workload排序
    def __lt__(self, other):
        # 先比较priority，如果不同则返回结果
        if self.priority != other.priority:
            return self.priority > other.priority
        # 如果priority相同，则比较workload
        return self.workload < other.workload


class Taskqueue:
    def __init__(self):
        self.tasks = []
        self.task_num = 0
        
    def generate_tasks(self, num=1):
        for _ in range(num):
            task = Task()
            task.type = "move"
            task.duration = random.randint(1, 5)
            task.workload = random.randint(1, 20)
            task.priority = random.randint(1, 5)  # 1-5的优先级，1为最低
            self.tasks.append(task)
        self.task_num += num
        # 生成任务后自动排序
        self._sort_tasks()
    
    def add_task(self, task):
        """添加单个任务并自动排序"""
        self.tasks.append(task)
        self.task_num += 1
        self._sort_tasks()
        
    def _sort_tasks(self):
        """内部方法：按照priority和workload排序任务队列"""
        self.tasks.sort()
    
    def pop_task(self):
        if self.task_num > 0:
            # 由于列表已经排序，直接取出第一个元素就是优先级最高且工作量最小的任务
            task = self.tasks.pop(0)
            self.task_num -= 1
            return task
        else:
            return None
    
    def get_task(self):
        return self.tasks[0]
    
    def __str__(self):
        return f"任务队列中剩余{self.task_num}个任务"


#任务处理中心
class Center:
    def __init__(self,tasks=None):
        if tasks is None:
            self.taskqueue=Taskqueue()
        else:
            self.taskqueue=tasks
    
    #分配任务
    def assign_task(self,vehicles):
        if self.taskqueue.task_num>0:
            task=self.taskqueue.get_task()
            results={}
            for vehicle in vehicles:
                if vehicle.state.battery>=task.workload and (vehicle.state.maxload-vehicle.state.current_load)>=task.workload:
                    results[vehicle]=task
                    vehicle.state.battery-=task.workload
                    vehicle.state.current_load+=task.workload
                    break
            return results
        else:
            return None
    






#.............................................


class DroneVisualizer:
    def __init__(self, vehicle):
        self.vehicle = vehicle
        self.root = None
        self.fig = None
        self.canvas = None
        self.ani = None
        self.running = False
        self.data_lock = threading.Lock()  # 用于保护共享数据
        self.interval_lock = threading.Lock()  # 用于保护更新间隔
        self.current_interval = 500  # 默认更新间隔（毫秒）
        
        # 数据存储 - 扩展添加Z坐标和线速度数据
        self.positions = []  # 存储 [x, y, z] 坐标
        self.battery_levels = []
        self.velocities = []  # 存储 [vx, vy, vz] 线速度
        self.times = []
        self.start_time = time.time()
        self.max_points = 500
    
    def start(self):
        """在主线程中启动可视化窗口"""
        # 确保在主线程中创建Tk窗口
        if threading.current_thread() != threading.main_thread():
            print("警告：可视化应该在主线程中启动以避免Tcl错误")
        
        self.root = tk.Tk()
        self.root.title(f"无人机可视化 - {self.vehicle.drone_name}")
        
        # 创建控制面板
        self._create_control_panel()
        
        # 创建图形
        self._create_figure()
        
        # 关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        self.running = True
        
        # 启动数据更新线程
        self.update_thread = threading.Thread(target=self._update_data_loop)
        self.update_thread.daemon = True
        self.update_thread.start()
        
        # 启动主事件循环
        try:
            self.root.mainloop()
        except Exception as e:
            print(f"可视化窗口运行出错: {e}")
        finally:
            self.running = False
            self._cleanup()
    
    def _cleanup(self):
        """清理所有资源"""
        try:
            if self.ani:
                self.ani.event_source.stop()
                self.ani = None
            if self.canvas:
                self.canvas.get_tk_widget().destroy()
                self.canvas = None
            if self.fig:
                plt.close(self.fig)
                self.fig = None
            if self.root:
                # 确保root窗口已经销毁
                if self.root.winfo_exists():
                    self.root.destroy()
        except Exception as e:
            print(f"清理资源时出错: {e}")
    
    
    def _create_control_panel(self):
        """创建控制界面"""
        control_frame = tk.Frame(self.root)
        control_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # 刷新间隔控制
        tk.Label(control_frame, text="刷新间隔(ms):").pack(side=tk.LEFT, padx=5)
        self.interval_var = tk.IntVar(value=500)
        interval_entry = tk.Entry(control_frame, textvariable=self.interval_var, width=5)
        interval_entry.pack(side=tk.LEFT, padx=5)
        
        # 应用按钮
        apply_btn = tk.Button(control_frame, text="应用", command=self.apply_settings)
        apply_btn.pack(side=tk.LEFT, padx=5)
        
        # 清除数据按钮
        clear_btn = tk.Button(control_frame, text="清除数据", command=self.clear_data)
        clear_btn.pack(side=tk.LEFT, padx=5)
        
        # 退出按钮
        exit_btn = tk.Button(control_frame, text="退出", command=self.on_closing)
        exit_btn.pack(side=tk.RIGHT, padx=5)

    
    def _create_figure(self):
        """创建matplotlib图形 - 优化布局以显示更多数据"""
        # 修改为3行布局，增加Z坐标和线速度的显示
        self.fig, ((self.ax_position_xy, self.ax_position_xz), 
                  (self.ax_battery, self.ax_velocity)) = plt.subplots(2, 2, figsize=(10, 8))
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # 设置图形
        self.setup_plots()
        
        # 动画 - 设置save_count避免缓存警告
        self.ani = FuncAnimation(self.fig, self.update_plot, interval=500, 
                                 cache_frame_data=False, save_count=100)
    
    
    
    def apply_settings(self):
        """应用用户设置的刷新间隔"""
        try:
            interval = max(100, self.interval_var.get())
            self.ani.event_source.interval = interval
            # 同时更新线程安全的间隔值
            with self.interval_lock:
                self.current_interval = interval
        except Exception as e:
            print(f"应用设置时出错: {e}")
            self.interval_var.set(500)
            with self.interval_lock:
                self.current_interval = 500
    
    def clear_data(self):
        """清除所有历史数据"""
        with self.data_lock:
            self.positions = []
            self.battery_levels = []
            self.times = []
            self.start_time = time.time()
        # 使用after方法在主线程中更新图表
        if self.root:
            self.root.after(0, lambda: self.update_plot(0))
    
    def _update_data_loop(self):
        """在后台线程中更新无人机数据 - 增加Z坐标和线速度数据收集"""
        while self.running:
            try:
                # 安全地获取更新间隔，不直接访问Tkinter变量
                interval = 500  # 默认值
                with self.interval_lock:
                    interval = self.current_interval
                interval = max(100, interval) / 1000  # 转换为秒
                
                # 更新无人机状态
                self.vehicle.updateState()
                current_time = time.time() - self.start_time
                
                # 安全地更新数据
                with self.data_lock:
                    self.times.append(current_time)
                    self.positions.append(self.vehicle.state.position.copy())
                    self.battery_levels.append(self.vehicle.state.battery)
                    # 新增：收集线速度数据
                    self.velocities.append(self.vehicle.state.linear_velocity.copy())
                    
                    # 限制数据点数量
                    if len(self.times) > self.max_points:
                        self.times = self.times[-self.max_points:]
                        self.positions = self.positions[-self.max_points:]
                        self.battery_levels = self.battery_levels[-self.max_points:]
                        self.velocities = self.velocities[-self.max_points:]
                
                # 等待下一次更新
                time.sleep(interval)
            except Exception as e:
                if self.running:  # 只有在仍然运行时打印错误
                    print(f"更新数据时出错: {e}")
                time.sleep(0.5)  # 出错时暂停0.5秒再尝试
    
    
    def setup_plots(self):
        """设置所有图表的属性"""
        # XY平面位置图
        self.ax_position_xy.set_title("无人机位置变化 (X-Y平面)")
        self.ax_position_xy.set_xlabel("X 坐标 (米)")
        self.ax_position_xy.set_ylabel("Y 坐标 (米)")
        self.ax_position_xy.grid(True, linestyle='--', alpha=0.7)
        self.ax_position_xy.set_aspect('equal')
        
        # XZ平面位置图（新增）
        self.ax_position_xz.set_title("无人机位置变化 (X-Z平面)")
        self.ax_position_xz.set_xlabel("X 坐标 (米)")
        self.ax_position_xz.set_ylabel("Z 坐标 (米)")
        self.ax_position_xz.grid(True, linestyle='--', alpha=0.7)
        self.ax_position_xz.set_aspect('equal')
        
        # 电池电量图
        self.ax_battery.set_title("电池电量变化")
        self.ax_battery.set_xlabel("时间 (秒)")
        self.ax_battery.set_ylabel("电量 (%)")
        self.ax_battery.set_ylim(0, 105)
        self.ax_battery.grid(True, linestyle='--', alpha=0.7)
        
        # 线速度图（新增）
        self.ax_velocity.set_title("线速度变化")
        self.ax_velocity.set_xlabel("时间 (秒)")
        self.ax_velocity.set_ylabel("速度 (米/秒)")
        self.ax_velocity.grid(True, linestyle='--', alpha=0.7)
        
        self.fig.tight_layout()
    
    
    def update_plot(self, frame):
        """更新图表显示，此方法在主线程中调用 - 增加Z坐标和线速度的可视化"""
        try:
            # 安全地获取数据副本
            with self.data_lock:
                times = self.times.copy()
                positions = self.positions.copy()
                battery_levels = self.battery_levels.copy()
                velocities = self.velocities.copy()
            
            # 清除所有图表
            self.ax_position_xy.clear()
            self.ax_position_xz.clear()
            self.ax_battery.clear()
            self.ax_velocity.clear()
            self.setup_plots()
            
            # 更新位置图
            if len(positions) > 1:
                pos_array = np.array(positions)
                
                # XY平面轨迹
                self.ax_position_xy.plot(pos_array[:, 0], pos_array[:, 1], 'b-', alpha=0.6, linewidth=1)
                self.ax_position_xy.plot(pos_array[:, 0], pos_array[:, 1], 'bo', alpha=0.3, markersize=3)
                self.ax_position_xy.plot(pos_array[-1, 0], pos_array[-1, 1], 'r', marker='x', markersize=10)
                self.ax_position_xy.annotate(f"X={pos_array[-1, 0]:.2f}, Y={pos_array[-1, 1]:.2f}",
                                          xy=(pos_array[-1, 0], pos_array[-1, 1]),
                                          xytext=(10, 10),
                                          textcoords='offset points',
                                          bbox=dict(boxstyle='round,pad=0.5', fc='yellow', alpha=0.5),
                                          arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=.2'))
                
                # XZ平面轨迹（新增）
                self.ax_position_xz.plot(pos_array[:, 0], pos_array[:, 2], 'g-', alpha=0.6, linewidth=1)
                self.ax_position_xz.plot(pos_array[:, 0], pos_array[:, 2], 'go', alpha=0.3, markersize=3)
                self.ax_position_xz.plot(pos_array[-1, 0], pos_array[-1, 2], 'r', marker='x', markersize=10)
                self.ax_position_xz.annotate(f"X={pos_array[-1, 0]:.2f}, Z={pos_array[-1, 2]:.2f}",
                                          xy=(pos_array[-1, 0], pos_array[-1, 2]),
                                          xytext=(10, 10),
                                          textcoords='offset points',
                                          bbox=dict(boxstyle='round,pad=0.5', fc='green', alpha=0.5),
                                          arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=.2'))
            
            # 更新电池图
            self.ax_battery.plot(times, battery_levels, 'g-', linewidth=2)
            self.ax_battery.axhline(y=20, color='r', linestyle='--', alpha=0.5)
            self.ax_battery.axhline(y=50, color='y', linestyle='--', alpha=0.5)
            
            if battery_levels:
                current_battery = battery_levels[-1]
                self.ax_battery.annotate(f"{current_battery:.1f}%",
                                        xy=(times[-1], current_battery),
                                        xytext=(0, 10),
                                        textcoords='offset points',
                                        bbox=dict(boxstyle='round,pad=0.5', fc='white', alpha=0.7),
                                        arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=.2'))
            
            # 更新线速度图（新增）
            if len(velocities) > 1:
                vel_array = np.array(velocities)
                self.ax_velocity.plot(times, vel_array[:, 0], 'r-', linewidth=1.5, label='Vx')
                self.ax_velocity.plot(times, vel_array[:, 1], 'g-', linewidth=1.5, label='Vy')
                self.ax_velocity.plot(times, vel_array[:, 2], 'b-', linewidth=1.5, label='Vz')
                self.ax_velocity.legend(loc='upper right')
                
                # 标记最新线速度
                if vel_array.any():
                    current_vx, current_vy, current_vz = vel_array[-1]
                    self.ax_velocity.annotate(f"Vx={current_vx:.2f}",
                                             xy=(times[-1], current_vx),
                                             xytext=(10, 0),
                                             textcoords='offset points',
                                             bbox=dict(boxstyle='round,pad=0.3', fc='red', alpha=0.3))
                    self.ax_velocity.annotate(f"Vy={current_vy:.2f}",
                                             xy=(times[-1], current_vy),
                                             xytext=(10, 0),
                                             textcoords='offset points',
                                             bbox=dict(boxstyle='round,pad=0.3', fc='green', alpha=0.3))
                    self.ax_velocity.annotate(f"Vz={current_vz:.2f}",
                                             xy=(times[-1], current_vz),
                                             xytext=(10, 0),
                                             textcoords='offset points',
                                             bbox=dict(boxstyle='round,pad=0.3', fc='blue', alpha=0.3))
            
            # 调整X轴范围，保持动态视图
            if times:
                time_range = max(0, times[-1] - 30)
                self.ax_battery.set_xlim(time_range, times[-1] + 5)
                self.ax_velocity.set_xlim(time_range, times[-1] + 5)
            
            # 确保图形布局正确
            self.fig.tight_layout()
            
        except Exception as e:
            print(f"更新图形出错: {e}")
        
        # 由于我们使用单独的线程更新数据，这里返回None即可
        return None

    
    def on_closing(self):
        """关闭窗口的处理函数"""
        try:
            self.running = False
            # 确保Tkinter操作在正确的线程中
            if self.root and self.root.winfo_exists():
                self.root.quit()
                self.root.destroy()
            self._cleanup()
        except Exception as e:
            print(f"关闭可视化窗口时出错: {e}")

# 全局变量用于控制可视化的启动和停止
_visualizer = None
_visualizer_thread = None

# 启动无人机可视化
def start_drone_visualization(vehicle):
    global _visualizer, _visualizer_thread
    
    # 关闭已经存在的可视化窗口
    if _visualizer:
        stop_drone_visualization()
        time.sleep(0.5)
    
    # 创建可视化器实例
    _visualizer = DroneVisualizer(vehicle)
    
    # 在单独线程中启动可视化
    _visualizer_thread = threading.Thread(target=_visualizer.start)
    _visualizer_thread.daemon = True
    _visualizer_thread.start()
    
    return _visualizer_thread

# 停止无人机可视化
def stop_drone_visualization():
    global _visualizer, _visualizer_thread
    
    if _visualizer:
        try:
            # 设置停止标志，让可视化线程自行关闭
            _visualizer.running = False
            
            # 不要直接调用on_closing()，让线程自己处理
            # 等待一小段时间确保窗口正确关闭
            if _visualizer_thread and _visualizer_thread.is_alive():
                _visualizer_thread.join(timeout=2.0)  # 等待最多2秒
        except Exception as e:
            print(f"关闭可视化窗口时出错: {e}")
        finally:
            _visualizer = None
            _visualizer_thread = None
